# time

> See how long a command takes

- Time "ls"

`time ls`
