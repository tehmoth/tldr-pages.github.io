# tpp

> Command-Line based presentation tool.

- View a presentation:

`tpp {{filename}}`

- Output a presentation:

`tpp -t {{type}} -o {{outputname}} {{filename}}`
