# apropos

> Search in manpages, for example to find a new command.

- Search for keyword:

`apropos {{regular_expression}}`

- Search without restricting output to terminal width:

`apropos -l {{regular_expression}}`
