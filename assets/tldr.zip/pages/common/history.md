# history

> Command Line history.

- Display the history list with line number

`history`

- Clear the history list

`history -c`
