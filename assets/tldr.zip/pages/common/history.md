# history

> Command Line history.

- Display the commands history list with line numbers:

`history`

- Clear the commands history list (only for `bash`):

`history -c`
