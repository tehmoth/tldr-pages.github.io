# zbarimg

> scan and decode bar codes from image file(s)

- process an image file

`zbarimg {{image file}}`
