# zbarimg

> Scan and decode bar codes from image file(s).

- Process an image file:

`zbarimg {{image file}}`
