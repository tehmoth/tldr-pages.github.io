# pandoc

> General markup converter.

- Convert file to pdf (the output format is automatically determined from the output file's extension):

`pandoc {{input.md}} -o {{output.pdf}}`
