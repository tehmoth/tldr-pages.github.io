# whoami

> Show the username of the current user.

- Display currently logged user name:

`whoami`
