# git merge

> Merge branches

- Merge a branch with your current branch

`git merge {{BRANCH-NAME}}`

- Edit the merge message

`git merge -e {{BRANCH-NAME}}`
