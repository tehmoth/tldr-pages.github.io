# file

> Determine file type.

- Give a description of the type of the specified file.  Works fine for files with no file extension:

`file {{filename}}`

- Look inside a zipped file and determine the file type(s) inside:

`file -z {{foo.zip}}`
