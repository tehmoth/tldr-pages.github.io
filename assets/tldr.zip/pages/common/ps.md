# ps

> Information about running processes

- list all running processes

`ps aux`

- list all running processes including the full command string

`ps auxww`

- search for a process that matches a string

`ps aux | grep {{string}}`
