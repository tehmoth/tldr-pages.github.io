# node

>Main node command

- Call an interactive node shell

`node`

- Execute node on a JS file

`node {{FILENAME}}.js`
