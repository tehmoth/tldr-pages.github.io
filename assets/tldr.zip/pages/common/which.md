# which

> Locate the a program in the user's path

- Display the path of an executable program

`which {{ls}}`
`which {{executable}}`

- If there are multiple executables which match, display all

`which -a {{executable}}`
