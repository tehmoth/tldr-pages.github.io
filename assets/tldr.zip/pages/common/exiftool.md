# exiftool

> Read and write meta information in files.

- Remove all EXIF metadata from the given files:

`exiftool -All= {{file}}`
