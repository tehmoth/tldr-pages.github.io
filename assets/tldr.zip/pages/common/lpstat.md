# lpstat

> print status information about printers

- List printers present on the machine and whether they are enabled for printing.

`lpstat -p`

- Print the default printer name.

`lpstat -d`
