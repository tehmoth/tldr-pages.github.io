# nginx

> nginx web server

- Start server with default config

`nginx`

- Start server with custom config and custom relative path base directory

`nginx -c {{path to config}} -p {{relative path base dir}}`
