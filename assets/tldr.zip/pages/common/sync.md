# sync

> Flushes all pending write operations to the appropriate disks.

- Flush all pending write operations on all disks:

`sync`

- Flush all pending write operations on a single file to disk:

`sync {{path/to/file}}`
