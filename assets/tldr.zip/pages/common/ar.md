# ar

> Create, modify, and extract from archives (.a .so .o)

- Extract members of the archive

`ar -x libfoo.a`

- List the content (files) of libfoo.a

`ar -t libfoo.a`
