# emacs

> The extensible, customizable, self-documenting, real-time display editor.

- Open emacs in console mode (without X window):

`emacs -nw`

- Open a file in emacs:

`emacs {{filename}}`

- Exit emacs:

`C-x C-c`
