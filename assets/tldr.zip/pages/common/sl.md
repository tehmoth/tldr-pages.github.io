# sl

> Steam locomotive running through your terminal.

- Let a steam locomotive run through your terminal.

`sl`

- The train burns, people scream.

`sl -a`

- Let the train fly.

`sl -F`
