# mkdir

> Creates a directory.

- Creates a directory in current folder or given path:

`mkdir {{directory}}`

- Creates directories recursively (useful for creating nested dirs):

`mkdir -p {{path}}`
