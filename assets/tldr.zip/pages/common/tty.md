# tty

> Returns terminal name.

- Print the file name of this terminal:

`tty`
