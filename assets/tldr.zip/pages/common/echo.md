# echo

> Print given arguments.

- Print a text message. Note: quotes are optional:

`echo {{"Hello World"}}`

- Print a message with environment variables:

`echo {{"My path is $PATH"}}`
