# gulp

> JavaScript task runner and streaming build system.
> Tasks are defined within gulpfile.js at the project root.

- Run the default task:

`gulp`

- Run individual tasks:

`gulp {{task}} {{othertask}}`
