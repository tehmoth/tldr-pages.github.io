# jar

> Java Applications/Libraries Packager.

- Unzip .jar/.war file to the current directory:

`jar -xvf *.jar`
