# elinks

> A text based browser similar to lynx.

- Start the browser:

`elinks`

- Quit the browser:

`ctrl+c`

- Dump output of webpage to console colorizing the text with ANSI control codes:

`elinks -dump -dump-color-mode {{1}} {{url}}`
