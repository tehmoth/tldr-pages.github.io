# atom

> A cross-platform text editor.

- Open a file or folder:

`atom {{path/to/file/or/folder}}`

- Open a file or folder in a new window:

`atom -n {{path/to/file/or/folder}}`
