# git cherry-pick

> Apply the changes introduced by some existing commits to the current branch.
> To apply changes to another branch, first use git-checkout to switch to the desired branch.

- Apply commit to current branch:

`git cherry-pick {{commit_hash}}`
