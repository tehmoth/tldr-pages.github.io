# df

> gives an overview of the file system disk space usage

- display all file systems and their disk usage

`df`

- display all file systems and their disk usage in human readable form

`df -h`
