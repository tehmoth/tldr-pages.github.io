# fortune

> Print a random quotation (fortune-cookie style).

- Print a quotation:

`fortune`

- Print a quotation from a given database:

`fortune {{database}}`

- Print a list of quotation databases:

`fortune -f`

- Print an offensive quotation:

`fortune -o`

- Print a long quotation:

`fortune -l`

- Print a short quotation:

`fortune -s`
