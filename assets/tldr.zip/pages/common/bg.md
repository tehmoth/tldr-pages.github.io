# bg

> Resumes suspended jobs and keeps them running in the background.

- Resume most recently suspended background job running in the background:

`bg`

- Resume a specific job running in the background:

`bg {{job_id}}`
