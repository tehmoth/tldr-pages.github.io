# Gradle

> Gradle is the official build system for Android Studio

- Compile a package

`gradle build`

- Clear the build folder

`gradle clean`

- Compile and Release package

`gradle assembleRelease`
