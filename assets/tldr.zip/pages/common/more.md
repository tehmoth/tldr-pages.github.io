# more

> Opens a file for reading.
> Allows movement and search in forward direction only.
> Doesn't read the entire file (suitable for logs)

- open a file

`more {{source_file}}`

- page down

`d (next)`

- search for a string

`/{{something}}   then   n (next)`

- exit

`q`
