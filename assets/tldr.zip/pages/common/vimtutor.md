# vimtutor

> Vim tutor, teaching the basic vim commands.

- Launch the vim tutor using the given language (en, fr, de, ...):

`vimtutor {{language}}`

- Exiting the tutor:

`[Esc] (to switch to normal mode), then :q`
