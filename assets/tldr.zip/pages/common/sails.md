# sails

> Sails.js is a realtime enterprise level MVC framework built on top of Node.js.

- Start Sail:

`sails lift`

- Create new Sails projec:

`sails new {{projectName}}`

- Generate Sails AP:

`sails generate {{name}}`

- Generate Sails Controlle:

`sails generate controller {{name}}`

- Generate Sails Mode:

`sails generate model {{name}}`
