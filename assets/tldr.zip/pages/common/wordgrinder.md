# wordgrinder

> Command-line Based Word Processor.

- Start wordgrinder. Loads a blank document by default:

`wordgrinder`

- Open a given file:

`wordgrinder {{filename}}`

- Open menu:

`Alt + M`
