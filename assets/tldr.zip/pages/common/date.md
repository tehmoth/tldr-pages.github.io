# date

> Set or display the system date

- Display the date using the default locale

`date +"%c"`

- Display the date using a custom format

`date +"%d/%m/%Y %H:%M:%S"`
