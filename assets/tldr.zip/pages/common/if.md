# if

> Simple shell conditional

- Echo a different thing depending on a command's success.

`{{command}} && echo "success" || echo "failure"`

- Full if syntax.

`if {{condition}}; then echo "true"; else echo "false"; fi`
