# kill

> Sends a signal to a process
> Mostly used for stopping processes

- kill the process

`kill {{process_id}}`

- list signal names

`kill -l`
