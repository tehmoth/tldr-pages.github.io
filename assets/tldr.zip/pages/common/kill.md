# kill

> Sends a signal to a process.
> Mostly used for stopping processes.

- Kill the process:

`kill {{process_id}}`

- List signal names:

`kill -l`
