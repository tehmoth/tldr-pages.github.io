# git pull

> Fetch branch from a remote repository and merge it to local repository

- Download changes from default remote repository and merge it

`git pull`

- Download changes from given remote repository and branch, then merge them into HEAD

`git pull {{remote_name}} {{branch}}`
