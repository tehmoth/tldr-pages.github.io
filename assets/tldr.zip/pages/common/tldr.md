# tldr

> Simplified man pages

- get typical usages of a command (hint: this is how you got here!)

`tldr {{command}}`
