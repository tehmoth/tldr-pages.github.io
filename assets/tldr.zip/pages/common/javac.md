# javac

> Java Application Compiler.

- Compile a .java file.

`javac {{filename.java}}`
