# zip

> Package and compress (archive) files into zip file

- package and compress multiple directories & files

`zip -r {{compressed.zip}} {{/path/to/dir1 /path/to/dir2 /path/to/file}}`
