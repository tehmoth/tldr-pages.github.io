# chsh

> Change user's login shell

- change shell

`chsh -s {{path/to/shell_binary}} {{username}}`
