# wuzz

> Tool to interactively inspect HTTP requests and responses.

- Display Help:

`F1`

- Send request:

`Ctrl+R`

- Next View:

`Ctrl+J, Tab`

- Previous View:

`Ctrl+K, Shift+Tab`
