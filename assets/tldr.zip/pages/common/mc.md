# mc

> Midnight Commander, a terminal based file manager.
> Navigate the folder structure using the arrow keys, the mouse or by typing the commands into the terminal.

- Start mc:

`mc`
