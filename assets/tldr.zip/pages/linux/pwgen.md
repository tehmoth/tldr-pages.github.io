# pwgen

> Generate passwords.

- Generate 8 characters long random passwords with symbols :

`pwgen -sy`
