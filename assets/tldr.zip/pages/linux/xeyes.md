# xeyes

> Display eyes on the screen that follow the mouse cursor.

- Launch xeyes on local display:

`xeyes`

- Launch xeyes on a remote display 0 screen 0:

`xeyes -display {{remote_host}}:{{0}}.{{0}}`
