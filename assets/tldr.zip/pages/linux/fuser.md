# fuser

> Display process IDs currently using files or sockets.
> Require admin privileges.

- Identify process using a TCP socket:

`fuser -n tcp {{port}}`
