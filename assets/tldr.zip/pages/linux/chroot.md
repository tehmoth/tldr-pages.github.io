# chroot

> Run command or interactive shell with special root directory.

- Run command as new root director:

`chroot {{/path/to/new/root}} {{command}}`

- Specify user and group (ID or name) to us:

`chroot −−userspec={{user:group}}`
