# apt-cache

> Debian and Ubuntu package query tool

- Search for a package in your current sources

`apt-cache search {{query}}`

- Show information about a package

`apt-cache show {{package}}`

- Show whether a package is installed and up to date

`apt-cache policy {{package}}`
