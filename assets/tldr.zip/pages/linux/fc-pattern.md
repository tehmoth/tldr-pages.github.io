# fc-pattern

> Shows information about a font matching a pattern.

- Display default infomation about a font:

`fc-pattern -d '{{DejaVu Serif}}'`
