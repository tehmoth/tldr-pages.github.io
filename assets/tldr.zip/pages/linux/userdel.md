# userdel

> Remove a user.

- Remove a user and their home directory:

`userdel -r {{name}}`
