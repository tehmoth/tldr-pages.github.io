# pkgadd

> Add a package to a CRUX system.

- Install a local software package:

`pkgadd {{package-name}}`

- Update an already installed package from a local package:

`pkgadd -u {{package-name}}`
