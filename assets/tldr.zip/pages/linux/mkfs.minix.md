# mkfs.minix

> Creates a Minix filesystem inside a partition.

- Create a Minix filesystem inside partition 1 on device b (`sdb1`):

`mkfs.minix {{/dev/sdb1}}`
