# tcpflow

> Capture TCP traffic for debugging and analysis

- Show all data on the given interface and port

`tcpflow -c -i {{eth0}} port {{80}}`
