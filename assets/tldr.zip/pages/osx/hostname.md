# hostname

> Show or set the system's host name.

- Show current host name:

`hostname`

- Set current host name:

`hostname {{new_hostname}}`
