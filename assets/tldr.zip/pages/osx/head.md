# head

> Output the first part of files

- Output the first few lines of a file

`head -n {{count of lines}} {{filename}}`

- Output the first few bytes of a file

`head -c {{number in kilobytes}} {{filename}}`
