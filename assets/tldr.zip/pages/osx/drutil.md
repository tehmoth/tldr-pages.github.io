# drutil

> Interact with DVD burners.

- Eject a disk from the drive:

`drutil eject`

- Burn a folder as an ISO9660 filesystem onto a DVD. Don't verify and eject when complete:

`drutil burn -noverify -eject -iso9660`
