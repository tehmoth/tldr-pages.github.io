# sw_vers

> Print Mac OSX Software versioning information

- Print OSX Version

`sw_vers -productVersion`

- Print OSX Build

`sw_vers -buildVersion`
