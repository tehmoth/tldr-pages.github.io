# qlmanage

> QuickLook server tool.

- Displays QuickLook for one or multiple files:

`quicklook -p {{filename}} {{filename2}}`

- Compute 300px wide PNG thumbnails of all JPEGs in the current directory and put them in a directory:

`quicklook *.jpg -t -s 300 {{/existing//thumbnail/directory}}`
