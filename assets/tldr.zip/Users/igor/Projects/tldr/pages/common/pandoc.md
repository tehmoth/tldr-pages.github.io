# pandoc

> General markup converter

- Convert file to pdf

`pandoc -o {{output.pdf}} {{input.md}}`
